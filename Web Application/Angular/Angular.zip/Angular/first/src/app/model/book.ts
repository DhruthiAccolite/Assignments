export class Book {
    id:string;
    bookName:string;
    description:string;
    authorName:string;
    price:number;
    checkout:string;
    // constructor(id,name,des,autname,price){
    //     this.id=id;
    //     this.authorName=autname;
    //     this.bookName=name;
    //     this.description=des;
    //     this.price=price;
    // }
}
